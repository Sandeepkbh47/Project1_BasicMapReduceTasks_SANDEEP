package task;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,DoubleWritable>{
     HashMap<String,String> hm=new HashMap<>();
     
     public void setup(Context context) throws IOException{
	 Path[] allFiles=DistributedCache.getLocalCacheFiles(context.getConfiguration());
	 
	 for(Path eachFile:allFiles){
		 BufferedReader br=new BufferedReader(new FileReader(eachFile.toString()));
		 
		 String line=null;
		 while((line=br.readLine())!=null){
			 String[] arr=line.split(" ");
			 String id=arr[0];
			 String name=arr[1];
			 hm.put(id, name);
		 }	       
		 br.close();		
	 }

     }
     
     
     public void map(LongWritable key,Text values,Context context) throws IOException, InterruptedException{
    	   String value=values.toString();
    	   
    	   String[] eachVal=value.split(" ");
    	   
    	   String id=eachVal[0];
    	   String amt=eachVal[1];
    	   String name=hm.get(id);
    	   
    	   Text mOutKey=new Text("User ID :"+id+" Name:"+name);
    	   
    	   DoubleWritable mOutVal = new DoubleWritable(Double.parseDouble(amt));
    	   context.write(mOutKey,mOutVal);
    	   
    		
    	   
     }
	
}
