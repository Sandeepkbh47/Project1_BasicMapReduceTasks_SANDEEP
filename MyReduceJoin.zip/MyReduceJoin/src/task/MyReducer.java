package task;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer  extends Reducer<Text,Text,Text,Text>{
	public void reduce(Text key, Iterable<Text> values, Context c) throws IOException, InterruptedException{
		double amount=0.0;
		String name=null;
		for(Text value: values){
			String[] eachVal = value.toString().split(":");
			if(eachVal[0].equals("amt"))
				amount+=Double.parseDouble(eachVal[1]);
			else
				name =eachVal[1];				
		}
		String[] s=key.toString().split(":");
		c.write(new Text(s[1]), new Text(" "+name+" "+amount));
	}

	

}
