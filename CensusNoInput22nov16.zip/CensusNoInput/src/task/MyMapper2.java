package task;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper2 extends Mapper<LongWritable,Text,IntWritable,Text> {
	
	    @Override
        public void map(LongWritable key,Text val,Context context) throws IOException, InterruptedException{
	    	     String line=val.toString();
	    	     int age=0;
	    	     int inc=0;
	    	     StringTokenizer st=new StringTokenizer(line,",");
	    	     while(st.hasMoreTokens()){
	    	     String[] word=st.nextToken().split(":");
	    	     if(word[0].equals("{\"Age\"")){
	    	    	 age=Integer.parseInt(word[1].trim());
	    	     }
	    	     if(word[0].equals("\"Income\"")){
	    	    	 double a=Double.parseDouble(word[1].trim());
	    	    	 int b=(int) a;
	    	    	 inc=b;
	    	     }
	    	     
	    	     
	       }
	    	     context.write(new IntWritable(age), new Text("sal:"+inc));
	    	     
			 }
}
