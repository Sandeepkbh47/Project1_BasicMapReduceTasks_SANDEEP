package task;


import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,IntWritable,Text> {
	
//	public void setup(Context context) throws IOException{
//		 Path[] allFiles=DistributedCache.getLocalCacheFiles(context.getConfiguration());
//		 
//		 for(Path eachFile:allFiles){
//			 BufferedReader br=new BufferedReader(new FileReader(eachFile.toString()));
//			 
//			 String line=null;
//			 while((line=br.readLine())!=null){
//				 String[] arr=line.split("\t");
//				 String id=arr[0];
//				 String name=arr[1];
//				 System.out.println(id+"   "+name);
//			 }	       
//			 br.close();		
//		 }
//
//	  }
	    @Override
        public void map(LongWritable key,Text val,Context context) throws IOException, InterruptedException{
	    	     String line=val.toString();
				 String[] arr=line.split("\t");
				 String age=arr[0].trim();
				 String grp=arr[1].trim();
				 context.write(new IntWritable(Integer.parseInt(age)), new Text("grp:"+grp));
			 }	 
          }
