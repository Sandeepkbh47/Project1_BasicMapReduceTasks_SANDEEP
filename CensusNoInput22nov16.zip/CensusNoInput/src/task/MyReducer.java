package task;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<IntWritable,Text,Text,Text>{
	
	
	HashMap<String,Integer> hm=new HashMap<>();
	
	public void cleanup(Context context) throws IOException, InterruptedException{
		Set<Map.Entry<String,Integer>> set=hm.entrySet();
		/*try{*/
		for(Map.Entry<String, Integer> s:set){
			context.write(new Text(s.getKey()), new Text(String.valueOf(s.getValue())));
		}/*}catch(Exception e){}*/
	}
	public void reduce(IntWritable key,Iterable<Text> values,Context context){
		    String grpname="etc";
	        int tamt=0;
		    for(Text value:values){
		     String line=value.toString();
		     String[] word=line.split(":");	    
		     if(word[0].equals("grp")){
		    	 grpname=word[1].trim();
		     }
		     if(word[0].equals("sal")){
		    	 //if (hm.containsKey(grpname)){
		    		 tamt+=Integer.parseInt(word[1]);
		     }
		    }
		     if (hm.containsKey(grpname)){
		    	 int storedAmt=hm.get(grpname);
		    	 tamt+=storedAmt;
		    	 hm.put(grpname, new Integer(tamt));	    		 
		    }
		     else{
		    		 hm.put(grpname, new Integer(tamt));
		     }
	      
	}  
}
