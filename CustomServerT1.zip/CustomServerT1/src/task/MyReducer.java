package task;

import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text,DoubleWritable,Text,Text>{
       public void reduce(Text key,Iterable<Text> values,Context context) throws IOException, InterruptedException{
    	   for(Text value:values){
			      context.write(value, null);
		   }
       }
}
