package task;

import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

public class MyTaskMapper extends Mapper<LongWritable,Text,Text,DoubleWritable>{
        
	    public void map(LongWritable key,Text values,Context context) throws IOException, InterruptedException{
	    	 String line=values.toString();
	    	 
	    	 String month=line.split(",")[1].split("-")[0];
	    	 
	    	 String samt=line.split(",")[3];
	    	 double amt=Double.parseDouble(samt);
	    	 
	    	 context.write(new Text(month), new DoubleWritable(amt));

	    	 
	    }
}
