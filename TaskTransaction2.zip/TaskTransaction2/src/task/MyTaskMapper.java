package task;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyTaskMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException{
 	   String line=value.toString();
 	   String[] eachWord=line.split(",");
 	   
 	   //Get the value at index position 3 for amt
 	   
 	   double amt= Double.parseDouble(eachWord[3]);
 	   
 	   if(amt>175d & amt<200d){
 		   context.write(new Text("Output"),new IntWritable(1));
 	   }        	           	   
 }
}
