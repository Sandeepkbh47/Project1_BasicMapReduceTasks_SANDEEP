package task;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {

	public static void main(String[] args) throws URISyntaxException, IOException, ClassNotFoundException, InterruptedException {
		 Configuration cfg=new Configuration();
	   	 
	   	 Job job=new Job(cfg,"Own Task 1 Map");
	   	 job.setNumReduceTasks(1);
	   	 job.setReducerClass(MyReducer.class);
	   	 job.setMapperClass(MyMapper.class);
	   	 job.setOutputKeyClass(Text.class);
	   	 job.setOutputValueClass(IntWritable.class);
	   	 job.setJarByClass(MyDriver.class);
	   	 FileInputFormat.addInputPath(job,new Path(args[0]));
	   	 FileOutputFormat.setOutputPath(job, new Path(args[1]));
	   	 
	   	 DistributedCache.addCacheFile(new URI("/home/hduser/task/DeptTaskData.dat"), job.getConfiguration());
	   	// DistributedCache.addCacheFile(new URI("/home/hduser/task/Transactional.dat"), job.getConfiguration());
	   	 
	   	 
	   	 System.exit(job.waitForCompletion(true)?0:1);

	}

}
