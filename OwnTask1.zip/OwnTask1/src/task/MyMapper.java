package task;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	
	
	TreeMap<Integer,String> tm1=new TreeMap<Integer,String>();
	@Override
	public void setup(Context context) throws IOException{
		Path[] path=DistributedCache.getLocalCacheFiles(context.getConfiguration());
		
		for(Path pt:path){
			 BufferedReader br=new BufferedReader(new FileReader(pt.toString()));
			 
			 String s=null;
			 while((s=br.readLine())!=null){
				 String[] word=s.split(",");
				 String deptid=word[0];
				 String oword=word[1].trim();
				 if(oword.equals("Executive")){
					tm1.put(Integer.parseInt(deptid),oword);
					//break;					 
				 }				 
			 }
             br.close();		
		}
	}
	
	public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException{
		       String line=value.toString();
		       String[] words=line.split(",");
               try{
		       String deptid=words[4].trim();
		     // if(tm1.get(Integer.parseInt(deptid)).contains("Executive")){
		    	   context.write(new Text(tm1.get(Integer.parseInt(deptid))), new IntWritable(1));
		      // }
               }catch(Exception e){}
		       
	}

}
