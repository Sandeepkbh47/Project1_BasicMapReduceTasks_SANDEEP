package task;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MySampleMapper extends Mapper<LongWritable,Text,Text,Text> {	
	
	public void map(LongWritable key,Text values,Context context) throws IOException, InterruptedException{
   	 String line=values.toString();
   	 
   	 String word=line.split(" ")[2];
   	 context.write(new Text(word), new Text("1"));
    }
}
