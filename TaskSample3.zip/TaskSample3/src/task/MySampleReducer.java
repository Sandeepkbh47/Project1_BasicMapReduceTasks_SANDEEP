package task;

import java.io.IOException;
//import java.util.Map.Entry;
//import java.util.Map.Entry;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MySampleReducer extends Reducer<Text,Text,Text,IntWritable>{
	//public static TreeMap<Integer,Text> tm=new TreeMap<Integer,Text>();
/*	public void cleanup(Context context) throws IOException, InterruptedException{
		   Entry<IntWritable, Text> ent=tm.lastEntry();
           context.write(ent.getValue(),ent.getKey());
	}
	*/
/*	public void cleanup(Context context) throws IOException, InterruptedException{
		   Entry<Integer, Text> ent=tm.lastEntry();
        context.write(new Text(ent.getValue()),new IntWritable(ent.getKey()));
	}*/
	
    public void reduce(Text key,Iterable<Text> values,Context context) throws IOException, InterruptedException{	
    	int max=0;
        String skey="";
        for(Text value:values){
        	int val=Integer.parseInt(value.toString().split(":")[1]);
        	String kval=value.toString().split(":")[0];
       	 if(max<val){
       		 max=val;
       		 skey=kval;
       	 }
        }
         
        context.write(new Text(skey), new IntWritable(max));
        // tm.put(key.toString() , new Integer(count));
        //tm.put(new Integer(count),key );
        // context.write(key,new IntWritable(count));
     }
}



