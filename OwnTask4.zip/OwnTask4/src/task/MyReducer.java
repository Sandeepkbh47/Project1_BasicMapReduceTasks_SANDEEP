package task;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<IntWritable,Text,Text,IntWritable>{
        public void reduce(IntWritable key,Iterable<Text> values,Context context) throws IOException, InterruptedException{
        	try{
        	int sum=0;
        	String name=null;
        	for(Text in:values){
        		
        		if(in.toString().split(":")[0].equalsIgnoreCase("sal")){
        			sum+=Integer.parseInt(in.toString().split(":")[1]);
        			
        		}else if(in.toString().split(":")[0].equalsIgnoreCase("name")){
        			  name=in.toString().split(":")[1];
        		}
	
        	}
        	
        	context.write(new Text(name), new IntWritable(sum));
        	}catch(Exception e){}
        }
}
