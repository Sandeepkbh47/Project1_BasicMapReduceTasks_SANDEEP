package task;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,IntWritable>{
	
	
	TreeMap<Integer,String> tm1=new TreeMap<Integer,String>();
	@Override
	public void setup(Context context) throws IOException{
		Path[] path=DistributedCache.getLocalCacheFiles(context.getConfiguration());
		
		for(Path pt:path){
			 BufferedReader br=new BufferedReader(new FileReader(pt.toString()));
			 
			 String s=null;
			 while((s=br.readLine())!=null){
				 String[] word=s.split(",");
				 String deptid=word[0];
				 String oword=word[1].trim();
				 if(oword.equals("IT")|oword.equals("Sales")){
					tm1.put(Integer.parseInt(deptid),oword);
					//break;					 
				 }				 
			 }
             br.close();		
		}
	}
	
	public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException{
		       String line=value.toString();
		       String[] words=line.split(",");
               try{
               int sal=Integer.parseInt(words[2]); 
		       String deptid=words[4].trim();
		     // if(tm1.get(Integer.parseInt(deptid)).contains("Executive")){
		           if (tm1.containsKey(new Integer(deptid)))
		    	   context.write(new Text(tm1.get(Integer.parseInt(deptid))), new IntWritable(sal));
		      // }
               }catch(Exception e){}
		       
	}

}
