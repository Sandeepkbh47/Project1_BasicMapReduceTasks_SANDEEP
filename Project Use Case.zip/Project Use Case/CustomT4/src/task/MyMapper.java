package task;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<MyKey, MyValue, Text, DoubleWritable> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		double amt = inpV.getAmt();
		    Configuration cfg=c.getConfiguration();
		    int month=Integer.parseInt(cfg.get("Month"));
		    if(Integer.parseInt(inpK.getid().toString())==month)
			c.write(inpK.getid(),new DoubleWritable(amt));
		    else if (month==0)
		    	c.write(inpK.getid(),new DoubleWritable(amt));
		}
}
