package task;

import java.io.IOException;
import java.util.TreeMap;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text,DoubleWritable,Text,DoubleWritable> {
	TreeMap<Text,DoubleWritable> tm=new TreeMap<Text,DoubleWritable>();
	
	@Override 
	public void cleanup(Context context) throws IOException, InterruptedException{
		 context.write(new Text("Stupid"),new DoubleWritable(34));
	 }
	  
	public void checkit(){
		
	}
    public void reduce(Text key,DoubleWritable value,Context context) throws IOException, InterruptedException{ 
    	/*double maxamt=0d;
    	String pro=null; 
    	  if(maxamt<value.get()){
    		  maxamt=value.get();
    		  pro=key.toString();
    	   }
    	  if(pro!=null)*/
    	   //context.write(key, value);
    	  // tm.put(key, value);
    	   //tm.put(key, value);     
    }
}
