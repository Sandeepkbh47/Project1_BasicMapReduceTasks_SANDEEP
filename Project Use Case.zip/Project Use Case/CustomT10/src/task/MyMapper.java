package task;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<MyKey, MyValue, DoubleWritable, Text> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		Text line = new Text(inpV.getLine());
		
			c.write(new DoubleWritable(inpK.getid()),line);
		}
}

