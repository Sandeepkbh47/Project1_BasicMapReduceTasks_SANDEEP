package task;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text,Text,Text,Text>{
      public void reduce(Text key,Iterable<Text> values,Context context) throws IOException, InterruptedException{
    	  double pamt=0d;
    	  String pro="fgfh";
    	  for(Text value:values){
    		  String data=value.toString();
    		  String[] arg=data.split(":");
    		  
    		  if(arg[0].contains("amt")){
    			  if(arg[1]!=null){
    			  String er=arg[1];
    			   pamt+=Double.parseDouble(er);
    			  }
    		  }else{
    			  try{
    			  if(arg[1]!=null)
    			  pro=arg[1];
    			  }catch(Exception e){}
    		  }	  
    	  }
    	  String s=String.valueOf(pamt);
    	  Text pr=new Text(s);
    	  context.write(new Text(pro), pr);
      }
}
