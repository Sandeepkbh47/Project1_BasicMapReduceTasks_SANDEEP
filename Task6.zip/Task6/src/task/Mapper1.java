package task;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper1 extends Mapper<LongWritable,Text,Text,Text>{
      public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException{
    	  
    	    StringTokenizer st=new StringTokenizer(value.toString(),",");
    	    String id = null;String pro = new String("Dummy");
    	    int count=1;
    	    while(st.hasMoreTokens()){
    	    	if(count==1) id=st.nextToken();
    	    	if(count==5) pro=st.nextToken();
    	    	count++;
    	    }
    	    
    	    context.write(new Text(id),new Text("pro:"+pro));   	    
      }
}
