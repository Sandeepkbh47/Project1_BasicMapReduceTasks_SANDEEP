package task;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MyCombiner extends Reducer<Text, Text,Text, Text>{
    public void reduce(Text key,Iterable<Text> values,Context context) throws IOException, InterruptedException{
  	  double pamt=0d;
  	  String pro="rt";
  	  for(Text value:values){
  		  String data=value.toString();
  		  String[] arg=data.split(":");
  		  
  		  if(arg[0].equals("amt")){
  			   pamt+=Double.parseDouble(arg[1].toString());
  		  }else{
  			  pro=arg[1].toString();
  		  }	  
  	  }
  	  
  	  context.write(new Text(pro), new Text(String.valueOf(pamt)));
    }

}
