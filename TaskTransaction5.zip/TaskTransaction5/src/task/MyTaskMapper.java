package task;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

class MyTaskMapper extends Mapper<LongWritable,Text,Text,Text>{
	
	public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException{
		 String line=value.toString();
   	 
   	     String month=line.split(",")[1].split("-")[0];
   	 
   	     context.write(new Text(month), new Text(line));
		 
	}

}