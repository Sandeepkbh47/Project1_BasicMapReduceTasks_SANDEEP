package task;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<IntWritable,Text,Text,IntWritable>{
        public void reduce(IntWritable key,Iterable<Text> values,Context context) throws IOException, InterruptedException{
        	try{
        	int count=0;
        	String name=null;
        	for(Text in:values){
        		
        		if(in.toString().split(":")[0].equalsIgnoreCase("found")){
        			count++;
        			
        		}else if(in.toString().split(":")[0].equalsIgnoreCase("name")){
        			  name=in.toString().split(":")[1];
        		}
	     
        	}
        	
        	context.write(new Text(name), new IntWritable(count));
        	}catch(Exception e){}
        }
}
