package task;


import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper1 extends Mapper<LongWritable,Text,IntWritable,Text>{
	public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException{
		   /*    String line=value.toString();
		       String[] words=line.split(",");
               try{
		       String deptid=words[4].trim();
		     // if(tm1.get(Integer.parseInt(deptid)).contains("Executive")){
		    	   context.write(new Text(tm1.get(Integer.parseInt(deptid))), new IntWritable(1));
		      // }
               }catch(Exception e){}
		       */
		 String[] word=value.toString().split(",");
		 String deptid=word[0];
		 String oword=word[1].trim();
		 if(oword.equals("Executive") & deptid!=null){
			context.write(new IntWritable(Integer.parseInt(deptid)),new Text("name:"+"Executive"));
			//break;					 
		 }				 
	}

}
