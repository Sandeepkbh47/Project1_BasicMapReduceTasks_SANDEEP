package task;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable{
	Text line;
	
	public MyValue(){
		this.line = new Text();
	}
	public MyValue(Text line){
		this.line =line;
	};
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
		line.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		line.write(arg0);
	}
	
	public void setLine(Text line){
		this.line=line;
	}
	public Text getLine(){
		return line;
	}

}
