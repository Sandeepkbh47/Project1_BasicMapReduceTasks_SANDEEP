package ftask;

import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;

public class MyReducer extends Reducer<Text,IntWritable,Text,IntWritable> {

	public void reduce(Text inpK,IntWritable inpV,Context c) throws IOException, InterruptedException{
		c.write(inpK, inpV);
	}
}
