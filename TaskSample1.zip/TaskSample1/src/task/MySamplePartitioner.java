package task;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class MySamplePartitioner extends Partitioner<Text,Text>{

	@Override
	public int getPartition(Text arg0, Text arg1, int arg2) {
		String type=arg0.toString();
		if(type.equals("[ERROR]"))
		return 3;
		else if(type.equals("[DEBUG]"))
			return 2;
		else if(type.equals("[TRACE]"))
			return 1;
		else return 0;
	}
}
