package task;

import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

public class MyTaskMapper extends Mapper<LongWritable,Text,Text,DoubleWritable>{
	
	public void map(LongWritable key,Text value,Context context) throws IOException, InterruptedException{
		 String line=value.toString();
		 
		 String[] words=line.split(",");
		 double val=Double.parseDouble(words[3]);
		 
		 context.write(new Text(words[2]), new DoubleWritable(val));
		 
	}

}
