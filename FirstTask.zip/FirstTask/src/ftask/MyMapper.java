package ftask;

import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,IntWritable>{

	public void map(LongWritable key,Text value,Context c) throws IOException, InterruptedException{
		
		String s=value.toString();
		
		String[] val=s.split(",");
		
		String eVal=val[1];
		
		int myVal=Integer.parseInt(eVal);
		
		if(myVal>150){
		@SuppressWarnings("unused")
		IntWritable iout=new IntWritable(myVal);
		c.write(new Text(val[0]), null);
		}
			
	}
}
