package task;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<MyKey, MyValue, Text, IntWritable> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		double amt = inpV.getAmt();
		if(amt>175d & amt<200d){
			c.write(new Text("Output"),new IntWritable(1));
		}
	}

}
